# Tarife & Servicii SMURD

<h2 align="center"><mark style="color:red;"><strong>TARIFE MEDICALE & INTERVENȚII DE URGENȚĂ</strong></mark></h2>

***

{% hint style="info" %}
Personalul medical SMURD / Spitalul Central este dedicat salvării de vieți omenești. Refuzul de a acorda primul ajutor unui pacient (indiferent dacă este infractor sau om al legii) este strict interzis prin jurământul Hipocratic.
{% endhint %}

---

### 🏥 Servicii Spitalicești & Reanimare

| Serviciu Medical | Descriere | Tarif |
| :--- | :--- | :---: |
| **Resuscitare la fața locului (Defibrilator)** | Readucerea unui cetățean din comă pe teren | **3.000$** |
| **Tratament Pansamente & Bandaje** | Oprirea sângerării și vindecarea rănilor ușoare | **1.000$** |
| **Intervenție Chirurgicală de Urgență** | Extragerea gloanțelor / operație ortopedică | **6.000$** |
| **Trusă Prim-Ajutor (Medikit portabil)** | Pachet pentru uz personal în inventar | **1.500$** |
| **Bandaj Simplu (Bandage)** | Pansament steril | **400$** |
| **Fișă Medicală Psihologică (Port-Armă)** | Evaluare psihiatrică pentru obținere permis armă | **15.000$** |
| **Recoltare & Test Toxicologic (Drug-Test)** | Analiză sânge la solicitarea Poliției | **5.000$** |

---

### 🚨 Reguli de Intervenție pentru Medici

* Ambulanțele au prioritate absolută în trafic atunci când au semnalele aprinse.
* În timpul schimburilor de focuri active, medicii **nu vor pătrunde în focar** până când zona nu este securizată complet de Poliție (regula Safe Scene).
