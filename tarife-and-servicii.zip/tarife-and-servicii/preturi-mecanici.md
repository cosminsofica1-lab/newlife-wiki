# Prețuri & Servicii Mecanici

<h2 align="center"><mark style="color:blue;"><strong>LISTA OFICIALĂ DE TARIFE - SERVICE AUTO NEWLIFE</strong></mark></h2>

***

{% hint style="info" %}
Toate service-urile auto autorizate din Los Santos (Benny's, Los Santos Customs, Hayes Autos) respectă această grilă unică de prețuri pentru a asigura transparență și corectitudine pentru toți clienții.
{% endhint %}

---

### 🔧 Reparații, Întreținere & Tractări

| Serviciu Oferit | Descriere Lucrare | Preț Recomandat |
| :--- | :--- | :---: |
| **Kit de Reparație Rapidă (Repair Kit)** | Repară motorul pe loc în caz de pană minoră | **2.500$** |
| **Kit Pană Anvelopă (Tire Kit)** | Înlocuiește cauciucul spart | **1.000$** |
| **Reparație Completă Service (Mecanic)** | Repară motor, caroserie, parbrize și geometrie | **4.000$ - 7.000$** |
| **Curățare & Spălare Detailing** | Degresare și luciu caroserie | **500$** |
| **Tractare Platformă (Towing)** | Transportul mașinii avariate la cel mai apropiat service | **3.000$** |

---

### 🏎️ Upgrade-uri de Performanță

| Modificare | Nivel 1 | Nivel 2 | Nivel 3 | Nivel 4 (Max) |
| :--- | :---: | :---: | :---: | :---: |
| **Upgrade Motor (Engine)** | 10.000$ | 20.000$ | 35.000$ | 55.000$ |
| **Upgrade Frâne (Brakes)** | 6.000$ | 12.000$ | 20.000$ | - |
| **Transmisie Sport** | 8.000$ | 16.000$ | 28.000$ | - |
| **Suspensie Sport / Reglabilă**| 5.000$ | 10.000$ | 18.000$ | 25.000$ |
| **Kit Turbocharger** | - | - | - | **45.000$** |

---

### 🎨 Modificări Estetice & Vopsitorie

* **Vopsea Primară (Mată / Metalizată):** `2.500$`
* **Vopsea Perlată / Cameleon:** `5.000$`
* **Folie Geamuri Fumurie (Tint):** `3.000$`
* **Lumini Xenon / Neon Sub Mașină:** `7.500$`
* **Jante Personalizate & Fum Anvelope:** `4.000$ - 8.000$`
* **Bodykit (Bare, Praguri, Eleron, Capotă Carbon):** `15.000$ - 35.000$` per pachet complet.
