# Tarife Hitman & Agenție

<h2 align="center"><mark style="color:black;"><strong>SERVICII DISCRETE DE INVESTIGAȚII & ELIMINARE</strong></mark></h2>

***

{% hint style="danger" %}
Agenția de Hitman operează în cea mai mare discreție în universul NewLife. Niciun membru al agenției nu își va dezvălui identitatea IC, iar contactarea se realizează exclusiv prin mesaje codate sau intermediari stabiliți.
{% endhint %}

---

### 🎯 Lista de Servicii & Tarife

| Serviciu Solicitat | Descriere Serviciu | Tarif Minim |
| :--- | :--- | :---: |
| **Protecție VIP / Gardă de Corp Înarmată** | Escortă discretă la tranzacții mari sau întâlniri de afaceri (per oră) | **30.000$** |
| **Filaj & Culegere Informații (Investigație)** | Poze, locație domiciliu, traseu zilnic al țintei | **50.000$** |
| **Avertisment / Intimidare Fizică** | Bătaie fără ucidere, distrugere autovehicul țintă | **40.000$** |
| **Contract de Eliminare (Civil Obisnuit)** | Execuție rapidă fără urme | **100.000$** |
| **Contract de Eliminare (Lider Mafie / Membru Facțiune)** | Risc ridicat, planificare elaborată | **250.000$ - 500.000$** |

---

### ⚠️ Reguli Stricte pentru Contracte

1. **Fără Contracte fără Motiv IC Solid**: Nu se acceptă contracte motivate din ură OOC sau suferințe pe chat. Solicitantul trebuie să prezinte un motiv roleplay concret (datorie uriașă nereturnată, trădare de familie, etc.).
2. **Hitman-ul nu face RDM**: Înainte de executarea unui contract, victima trebuie avertizată printr-un semn simbolic sau dialog scurt de rol.
3. **Plata în Avans**: Toate contractele necesită achitarea a cel puțin 50% din sumă înainte de începerea operațiunii. Dacă ținta este protejată eficient și asasinul este neutralizat, avansul nu se returnează.
