# Amenzi & Taxe Poliție

<h2 align="center"><mark style="color:blue;"><strong>TAXE ADMINISTRATIVE ȘI RECUPERĂRI ACTE</strong></mark></h2>

***

Departamentul de Poliție NewLife percepe taxe fixe pentru emiterea actelor oficiale, recuperarea vehiculelor confiscate și procedurile legale de reabilitare.

---

### 📋 Taxe Administrative & Eliberare Documente

| Serviciu Polițienesc | Detalii & Condiții | Tarif Oficial |
| :--- | :--- | :---: |
| **Eliberare Duplicat Buletin / Act Identitate** | În caz de pierdere sau furt | **2.500$** |
| **Redobândire Permis de Conducere Suspendat** | După expirarea perioadei de suspendare | **10.000$** |
| **Examinare & Licență Port-Armă (Civil)** | Necesită test psihologic SMURD + cazier curat | **50.000$** |
| **Radiere Cazier Judiciar (Reabilitare)** | Ștergerea unei fapte vechi (minim 14 zile fără recidivă) | **75.000$** |
| **Eliberare Vehicul din Depozitul Poliției (Impound)** | Mașină ridicată pentru parcare neregulamentară | **5.000$** |
| **Eliberare Vehicul din Sechestru Judiciar** | Mașină confiscată în acțiuni ilegale / jafuri | **20.000$ - 50.000$** |
| **Cauțiune Eliberare Condiționată (Bail)** | Pentru infracțiuni non-violente (decisă de Comisar/Judecător) | **30.000$ - 100.000$** |

---

### 🏛️ Notă privind Plata Amenzilor

* Amenzile rutiere se pot plăti direct la orice bancomat (ATM) sau bancă din oraș, folosind tasta **`F7`** (Meniu Facturi).
* Neplata amenzilor în termen de 7 zile duce la blocarea conturilor bancare și emiterea unui mandat de aducere silită la secție!
