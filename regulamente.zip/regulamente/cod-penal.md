# Cod Penal & Legislație

<h2 align="center"><mark style="color:blue;"><strong>CODUL PENAL OFICIAL AL ORAȘULUI NEWLIFE</strong></mark></h2>

***

{% hint style="warning" %}
**Principii Generale de Aplicare:**
1. **Comportamentul Suspectului**: Polițistul poate ajusta pedeapsa între minimul și maximul prevăzut în funcție de atitudinea suspectului (cooperant, neutru, ostil).
2. **Cumulul de Pedepse**: În cadrul unui singur proces / arestare, o persoană nu poate fi reținută pentru mai mult de **3 infracțiuni cumulate**. Se aplică pedepsele celor mai grave 3 infracțiuni constatate.
3. **Complicitatea**: Complicele la o infracțiune primește **jumătate** din pedeapsa cu închisoarea și **jumătate** din amenda principală.
4. **Recunoașterea Faptei**: Dacă suspectul recunoaște fapta și colaborează cu anchetatorii, timpul de detenție poate fi redus cu **25% - 30%**.
{% endhint %}

---

## 🚗 CAPITOLUL I - Legislație Rutieră & Infracțiuni în Trafic

### Art. 1 - Parcarea Neregulamentară
* **Descriere:** Staționarea sau oprirea vehiculului pe trotuare, căi de acces pietonal, spații verzi sau zone marcate cu linie continuă galbenă.
* **Sancțiune:** Amendă: **3.000$** + Tractarea vehiculului la depozitul auto.

### Art. 2 - Trecerea pe Culoarea Roșie a Semaforului
* **Descriere:** Pătrunderea într-o intersecție semaforizată pe culoarea roșie.
* *(Excepție: În intervalul 00:00 - 05:00 semafoarele funcționează intermitent, dar traversarea impune oprirea și asigurarea prealabilă).*
* **Sancțiune:** Amendă: **5.000$** + 2 puncte penalizare.

### Art. 3 - Viteza Excesivă
* **Zone Urbane (Limită 80 km/h):**
  * Depășire cu 20 - 40 km/h: Amendă **5.000$**
  * Depășire cu peste 40 km/h: Amendă **10.000$** + Suspendarea permisului pentru 24 ore.
* **Autostrăzi & Drumuri Externe (Limită 140 km/h):**
  * Depășire peste limită: Amendă **7.500$**

### Art. 4 - Neacordarea de Prioritate Vehiculelor de Urgență
* **Descriere:** Neoprirea pe partea dreaptă și necedarea trecerii la apropierea autospecialelor SMURD / Poliție cu semnalele acustice și luminoase pornite.
* **Sancțiune:** Amendă: **15.000$**.

### Art. 5 - Conducerea Imprudentă & Drifturi Ilegale
* **Descriere:** Manopere de derapaj controlat (drift), condus pe contrasens, mers cu viteză pe trotuar sau sărituri peste rampe în zone populate.
* **Sancțiune:** Amendă: **12.000$** + 10 luni detenție.

### Art. 6 - Conducerea sub Influența Alcoolului sau a Substanțelor
* **Descriere:** Depistarea la drug-test sau etilotest cu rezultat pozitiv la volan.
* **Sancțiune:** Amendă: **20.000$** + 15 luni detenție + Suspendare permis 48 ore.

### Art. 7 - Conducerea Fără Permis Valabil
* **Descriere:** Operarea unui autovehicul fără a deține licență auto categoria B sau cu permisul suspendat.
* **Sancțiune:** Amendă: **15.000$** + Confiscarea/Tractarea vehiculului.

### Art. 8 - Părăsirea Locului Accidentului
* **Descriere:** Fuga de la locul unui impact rutier soldat cu pagube materiale sau vătămări corporale.
* **Sancțiune:** Amendă: **25.000$** + 20 luni detenție.

### Art. 9 - Fuga de Poliție (Neoprire la Semnale)
* **Descriere:** Ignorarea semnalelor luminoase și sonore ale autospecialei de poliție și inițierea unei urmăriri.
* **Sancțiune:** Amendă: **35.000$** + 30 luni detenție.

---

## 👥 CAPITOLUL II - Infracțiuni Contra Persoanei

### Art. 10 - Agresiune Fizică / Loviri
* **Descriere:** Lovirea intenționată a unui cetățean cu pumnii, picioarele sau obiecte contondente.
* **Sancțiune:** Amendă: **10.000$** + 15 luni detenție.

### Art. 11 - Vătămare Corporală Gravă
* **Descriere:** Aducerea victimei în stare critică sau de comă prin atac armat sau fizic repetat.
* **Sancțiune:** Amendă: **25.000$** + 35 luni detenție.

### Art. 12 - Tentativă de Omor
* **Descriere:** Deschiderea focului asupra unei persoane cu intenția clară de a o suprima, victima supraviețuind.
* **Sancțiune:** Amendă: **50.000$** + 50 luni detenție.

### Art. 13 - Omor deosebit de Grav
* **Descriere:** Uciderea deliberată a unei persoane civile sau a unui funcționar.
* **Sancțiune:** Amendă: **80.000$** + 80 luni detenție + Sechestru judiciar.

### Art. 14 - Răpire & Lipsire de Libertate
* **Descriere:** Imobilizarea, încătușarea și transportarea forțată a unei persoane împotriva voinței acesteia.
* **Sancțiune:** Amendă: **45.000$** + 45 luni detenție.

### Art. 15 - Șantaj și Amenințare
* **Descriere:** Constrângerea psihică sau amenințarea cu moartea pentru obținerea de bunuri sau bani.
* **Sancțiune:** Amendă: **20.000$** + 20 luni detenție.

---

## 🏛️ CAPITOLUL III - Infracțiuni Contra Patrimoniului

### Art. 16 - Furt Auto
* **Descriere:** Spargerea și sustragerea unui vehicul aparținând altui cetățean.
* **Sancțiune:** Amendă: **20.000$** + 25 luni detenție.

### Art. 17 - Jaf Armat asupra unui Magazin / Benzinărie
* **Descriere:** Tâlhărirea angajatului unui magazin 24/7 sub amenințarea armei.
* **Sancțiune:** Amendă: **30.000$** + 35 luni detenție.

### Art. 18 - Jaf Armat asupra unei Bănci / Bijuterii
* **Descriere:** Spargerea seifurilor unei bănci (Fleeca, Pacific) sau vitrinelor Vangelico.
* **Sancțiune:** Amendă: **75.000$** + 75 luni detenție + Confiscarea prăzii.

### Art. 19 - Distrugerea Bunurilor Publice
* **Descriere:** Avarierea stâlpilor, hidranților, camerelor radar sau autospecialelor de stat.
* **Sancțiune:** Amendă: **15.000$** + Achitarea costurilor de reparație.

---

## 🔫 CAPITOLUL IV - Regimul Armelor & Substanțelor Interzise

### Art. 20 - Port Ilegal de Armă Albă
* **Descriere:** Deținerea la vedere în spațiul public a cuțitelor de luptă, săbiilor, macetelor, topoarelor.
* **Sancțiune:** Amendă: **10.000$** + Confiscarea armei.

### Art. 21 - Deținere Ilegală de Armă de Foc (Calibru Mic)
* **Descriere:** Posesia unui pistol fără permis legal de port-armă eliberat de Poliția NewLife.
* **Sancțiune:** Amendă: **30.000$** + 30 luni detenție + Confiscarea armei și muniției.

### Art. 22 - Deținere de Arme Militare / Calibru Mare
* **Descriere:** Deținerea sau utilizarea de arme automate (AK-47, M4, Uzi, puști cu pompă, puști cu lunetă).
* **Sancțiune:** Amendă: **70.000$** + 60 luni detenție + Confiscare totală.

### Art. 23 - Posesie de Substanțe Stupefiante (Consum)
* **Descriere:** Posesia a mai puțin de 10 grame de marijuana / cocaină / metamfetamină.
* **Sancțiune:** Amendă: **15.000$** + Confiscarea drogurilor.

### Art. 24 - Trafic de Substanțe Interzise (Comerț)
* **Descriere:** Posesia a peste 10 pachete de droguri, plante sau procesarea în laboratoare clandestine.
* **Sancțiune:** Amendă: **50.000$** + 55 luni detenție + Confiscare.

---

## 👮 CAPITOLUL V - Infracțiuni Contra Autorităților

### Art. 25 - Refuz de Legitimare
* **Descriere:** Refuzul de a prezenta buletinul sau permisul de conducere la solicitarea justificată a unui agent.
* **Sancțiune:** Amendă: **10.000$** + Conducerea la secție pentru identificare.

### Art. 26 - Ultragiu
* **Descriere:** Adresarea de cuvinte jignitoare, amenințări sau agresarea fizică a unui polițist sau medic în misiune.
* **Sancțiune:** Amendă: **35.000$** + 40 luni detenție.

### Art. 27 - Mituirea Funcționarului Public
* **Descriere:** Oferirea de sume de bani sau favoruri unui om al legii pentru a scăpa de sancțiuni.
* **Sancțiune:** Amendă: **40.000$** + 35 luni detenție.

### Art. 28 - Uzurparea de Calități Oficiale
* **Descriere:** Purtarea de elemente de uniformă de poliție/SMURD sau pretinderea că ești agent fără a fi angajat.
* **Sancțiune:** Amendă: **50.000$** + 45 luni detenție.

### Art. 29 - Evadarea din Custodie
* **Descriere:** Fuga din mașina de poliție, din celulele secției sau din Penitenciarul Bolingbroke.
* **Sancțiune:** Amendă: **50.000$** + Dublarea pedepsei inițiale.
