# Regulament General & Roleplay

<h2 align="center"><mark style="color:blue;"><strong>REGULAMENTUL OFICIAL NEWLIFE ROLEPLAY</strong></mark></h2>

***

{% hint style="info" %}
Toți jucătorii comunității **NewLife** au obligația de a cunoaște și respecta regulamentul în integralitate. Necunoașterea acestuia nu este acceptată ca scuză în cazul aplicării unei sancțiuni.
{% endhint %}

---

### <mark style="color:yellow;">**1. Termenul Roleplay ( RP )**</mark>

**Roleplay-ul** reprezintă simularea unei vieți reale prin intermediul unui personaj creat de jucător. La început, fiecare își alege identitatea (**nume, prenume, vârstă, aspect, istoric etc.**), iar acest caracter evoluează constant într-o poveste coerentă. Personajul rămâne activ pe toată durata jocului, până la un eventual **Character Kill (CK)**.

* Fiecare decizie luată în joc trebuie să aibă logică și să respecte limitele firii umane din viața reală.
* Nu aveți voie să jucați roluri nerealiste (ex: super-erou, nemuritor, personaj fără reacție la durere sau frică).

---

### <mark style="color:yellow;">**2. Termenul In Character ( IC )**</mark>

**IC (In Character)** reprezintă totalitatea acțiunilor, discuțiilor și informațiilor care au loc în joc, strict din perspectiva personajului tău:
* Din momentul conectării până la deconectare, trebuie să rămâneți **permanent IC**.
* Singura excepție este atunci când sunteți preluat într-un ticket administrativ și aveți permisiunea explicită a unui **membru staff**.
* Orice conflict IC (ex: rivalitate mafiotă, arestare de către poliție) trebuie să rămână **strict în joc** și să nu fie transpus în viața reală sau pe Discord.

---

### <mark style="color:yellow;">**3. Termenul Out Of Character ( OOC )**</mark>

**OOC (Out of Character)** reprezintă toate informațiile, discuțiile și acțiunile care provin din afara jocului (din viața reală):
* Este **strict interzisă** folosirea informațiilor OOC în IC, acest lucru fiind considerat **MetaGaming**.
* Este interzisă folosirea termenilor de tip "jargon OOC" în timpul roleplay-ului (ex: *"permiți chineză?"*, *"mușchiul K"*, *"merg pe insulă"*, *"vorbește pe creier"*, *"dau ticket la zei"*). Astfel de exprimări se consideră **întrerupere de roleplay (Fail RP)**.

---

### <mark style="color:yellow;">**4. Termenul Character Kill ( CK )**</mark>

**Character Kill ( CK )** reprezintă moartea definitivă a personajului și resetarea completă a tuturor bunurilor, averii și conexiunilor dobândite în IC până la acel moment.

{% hint style="danger" %}
**Consecințele unui Character Kill (CK):**
* Pierderea banilor (portofel și conturi bancare).
* Pierderea tuturor autovehiculelor obținute IC.
* Pierderea proprietăților (case, depozite, apartamente, afaceri).
* Pierderea tuturor itemelor și armelor.
* Excluderea automată din facțiunea sau organizația din care făceați parte.
* Resetarea identității și obligația de a crea un caracter complet nou (nume nou, aspect nou, poveste nouă).
{% endhint %}

{% hint style="warning" %}
**Reguli și Aprobare CK:**
1. Character Kill-ul poate fi aprobat **doar de Conducerea Serverului NewLife** (Fondatori / Co-Fondatori).
2. CK-ul poate fi acordat doar pe motive excepționale și bine documentate (trădare majoră a unei mafii, acumularea a peste 5 caziere grele neplătite, execuție oficială a instanței sau a Sindicatului).
3. **Fentare CK**: Transferul bunurilor către terțe persoane știind că urmează să primiți CK se pedepsește cu **Ban Permanent** pentru toți cei implicați.
{% endhint %}

---

### <mark style="color:yellow;">**5. Termenul Player Kill ( PK )**</mark>

**Player Kill ( PK )** reprezintă situația în care un jucător ajunge în stare critică (comă) și apasă tasta de respawn (după expirarea timer-ului de comă), fără intervenția unui echipaj SMURD:
* După un PK, personajul tău **uită complet** toate evenimentele care au dus la moartea sa, precum și persoanele implicate în conflictul respectiv.
* **Timp de 15 minute**, nu ai voie să revii în zona unde ai murit (regula NewLife Cooldown) și nu ai voie să reiei conflictul.
* Nu aveți voie să folosiți tertipuri de tip *"mi-a amintit un prieten ce s-a întâmplat"*.

---

### <mark style="color:yellow;">**6. Rob & Kill ( R&K ) și Drop & Kill ( D&K )**</mark>

* **Rob & Kill (R&K):** Este strict interzis să jefuiești un jucător și apoi să îl omori fără un motiv temeinic de viață și de moarte, ori să îl omori și apoi să îl jefuiești.
* **Drop & Kill (D&K):** Dacă obligi o persoană sub amenințarea armei să arunce toate bunurile sau banii, ești **obligat să o lași în viață**. Dacă alegi să o elimini, nu ai voie să îi iei bunurile aruncate forțat.

{% hint style="info" %}
**Excepție:** Dacă persoana jefuită devine ostilă, refuză să respecte comenzile sub amenințarea armei sau încearcă să riposteze armat (punându-ți viața în pericol), eliminarea acesteia este justificată (autoapărare).
{% endhint %}

---

### <mark style="color:yellow;">**7. Termenul Revenge Kill ( RK )**</mark>

**Revenge Kill ( RK )** reprezintă acțiunea prin care un jucător ucis într-un conflict revine după respawn/spital pentru a se răzbuna pe atacatorul său.
* Este **strict interzis** să cauți persoana care te-a omorât sau să transmiți pe radio/telefon coordonatele acesteia prietenilor tăi pentru ca aceștia să se răzbune în locul tău.

---

### <mark style="color:yellow;">**8. Termenul MetaGaming ( MG )**</mark>

**MetaGaming ( MG )** este folosirea oricăror informații obținute pe căi Out Of Character (Discord, apeluri vocale externe, stream-uri Twitch/TikTok/YouTube, chat global) în cadrul jocului (In Character).

{% hint style="danger" %}
* **Interzis pe Discord**: Folosirea canalelor vocale de Discord în timpul acțiunilor de roleplay (jafuri, urmăriri de poliție, războaie între mafii) este asimilată cu MetaGaming și se sancționează aspru.
* **Stream Sniping**: Folosirea transmisiunilor live ale altor jucători pentru a le afla locația, bunurile sau planurile este strict interzisă și atrage **Ban Permanent**.
{% endhint %}

---

### <mark style="color:yellow;">**9. Termenul PowerGaming ( PG )**</mark>

**PowerGaming ( PG )** reprezintă efectuarea unor acțiuni imposibile în viața reală, forțarea unui roleplay asupra altui jucător fără a-i acorda dreptul de replică, sau ignorarea consecințelor fizice (accidente grave).

**Exemple clare de PowerGaming:**
* Supraviețuirea fără nicio reacție de rol după un accident rutier frontal la peste 150 km/h (trebuie să simulezi comă, amețeli sau dureri prin `/me` și `/do`).
* Mersul sau fuga imediat după ce ai fost împușcat în picioare.
* Scrisul pe `/me` a unor acțiuni absolute: `/me îl leagă la mâini fără să poată scăpa` în loc de `/do Reușesc să te leg la mâini?`.
* Vorbitul la stație sau telefon în timp ce ești încătușat cu mâinile la spate.

---

### <mark style="color:yellow;">**10. Vehicle Deathmatch ( VDM ) & Car Ramming**</mark>

* **VDM (Vehicle Deathmatch):** Călcarea intenționată a altor jucători cu vehiculul cu scopul de a-i răni sau ucide.
* **Car Ramming:** Lovirea repetată și nerealistă a altor mașini cu autovehiculul personal pe post de „berbec”. Pentru oprirea unui vehicul în urmăriri se folosesc manevre PIT autorizate (la viteze sub 100 km/h), nu izbiri frontale.

---

### <mark style="color:yellow;">**11. Random Deathmatch ( RDM )**</mark>

**Random Deathmatch ( RDM )** reprezintă rănirea sau omorârea unui jucător fără un motiv plauzibil, fără o interacțiune roleplay prealabilă și fără avertismente verbale sau context logic.
* Înainte de a deschide focul, trebuie să existe un dialog clar și o revendicare rezonabilă (excepție: zonele de război între facțiuni declarate oficial sau intervenții SWAT în scenarii teroriste).

---

### <mark style="color:yellow;">**12. Fear RP ( Frica de Moarte / Arme )**</mark>

În viața reală, viața proprie este cel mai de preț bun. Pe **NewLife**, orice jucător este obligat să simuleze frica atunci când se află într-o situație de inferioritate netă sau cu arma îndreptată spre el:
* Dacă o persoană sau un grup are arma ațintită asupra ta de la distanță apropiată, **ești obligat să te supui cerințelor** (să ridici mâinile, să predai cheile etc.).
* Este interzis să scoți arma când cineva te ține deja sub vizor (acest lucru se numește **No-Fear**).
* Respectarea raportului de forțe: 1 polițist/civil nu poate ataca singur un grup de 4 persoane înarmate.

---

### <mark style="color:yellow;">**13. Cop Baiting**</mark>

Provocarea intenționată a forțelor de ordine (Poliție / Jandarmerie) fără un motiv de roleplay, doar pentru a declanșa o urmărire sau un schimb de focuri:
* Exemple: claxonat repetat lângă secție, drifturi ostentative în fața autospecialei de poliție, turat motorul la semafor sau strigăte jignitoare adresate agenților fără context.

---

### <mark style="color:yellow;">**14. Olympic Swimming & Bunny Hopping**</mark>

* **Olympic Swimming:** Înotul continuu și nerealist în largul oceanului zeci de minute pentru a scăpa de poliție sau de atacatori, purtând rucsac și arme grele pe tine.
* **Bunny Hopping:** Săriturile repetate și continue în timp ce alergi pentru a te deplasa mai rapid decât viteza normală de alergare.

---

### <mark style="color:yellow;">**15. Ninja Jack**</mark>

Furtul unui vehicul prin scoaterea forțată a șoferului de la volan (apasând tasta F) fără a efectua niciun fel de roleplay prealabil și fără a-l amenința corespunzător.

---

### <mark style="color:yellow;">**16. Combat Logging / Refuz Roleplay**</mark>

* Deconectarea de pe server (`Alt + F4`, `Quit`, deconectare cablu de net) în timpul unei acțiuni de roleplay (urmărire, arestare, jaf, bătaie, comă) este strict interzisă.
* În caz de crash real, jucătorul are la dispoziție **maxim 10 minute** pentru a reveni pe server și a anunța pe canalul de Discord `#crash-roleplay` revenirea la acțiune. În caz contrar, se aplică automat **Ban Temporar (3 - 7 zile)**.

---

### <mark style="color:yellow;">**17. Bug Abuse & Exploits**</mark>

Folosirea oricăror erori, glitch-uri de textură, multiplicări de iteme sau bani (duping) este strict interzisă.
* Orice bug descoperit trebuie raportat de urgență echipei staff prin ticket.
* Jucătorii care raportează bug-uri majore primesc recompense substanțiale IC / Discord! Tăinuirea sau exploatarea bug-urilor atrage **Ban Permanent fără drept de apel**.

---

### <mark style="color:yellow;">**18. Tranzacții OOC ( RMT - Real Money Trading )**</mark>

Vânzarea, cumpărarea sau schimbul de bani din joc, mașini, arme sau conturi pe bani reali sau alte bunuri externe este strict interzisă și atrage **Blacklist Permanent** pe comunitatea NewLife.
