# Sistem de Sancțiuni & Ore

<h2 align="center"><mark style="color:orange;"><strong>GRILA OFICIALĂ DE SANCȚIUNI ADMINISTRATIVE</strong></mark></h2>

***

{% hint style="info" %}
Pe comunitatea **NewLife**, sancțiunile se aplică pe baza **orelor totale acumulate pe cont**, nu pe caracter. Înțelegem că jucătorii noi au nevoie de îndrumare, în timp ce jucătorii cu experiență sunt datori să cunoască și să respecte regulamentul la cele mai înalte standarde.
{% endhint %}

---

### 🕒 Împărțirea pe Categorii de Ore

* **Categoria 1 (Jucători Începători):** `0 - 30 ore`
  * Se pune accent pe explicare și conștientizarea greșelii. La prima abatere minoră se acordă Avertisment Verbal (AV) sau Jail scurt cu îndrumare pe regulament.
* **Categoria 2 (Jucători Medii):** `30 - 150 ore`
  * Se aplică sancțiuni standard (Warn, Jail administrativ, Ban temporar scurt). Nu se mai acceptă scuza "sunt la început".
* **Categoria 3 (Jucători Avansați / Veterani):** `150+ ore`
  * Se aplică pedepse maxime fără circumstanțe atenuante. Greșelile grave atrag ban-uri extinse sau excluderea din facțiuni.

---

### 📋 Tabelul General de Sancțiuni

| Abatere Regulament | Jucător Începător (0-30h) | Jucător Mediu (30-150h) | Jucător Avansat (150h+) |
| :--- | :--- | :--- | :--- |
| **VDM (Vehicle Deathmatch)** | 30m Jail / Warn | 60m Jail + Warn | Ban 2 - 5 Zile |
| **RDM (Random Deathmatch)** | 45m Jail / Warn | Ban 1 - 3 Zile | Ban 3 - 7 Zile |
| **Fail RP (Acțiuni absurde)** | 20m Jail + Explicare | 45m Jail + Warn | Warn + 90m Jail |
| **PowerGaming (PG)** | 30m Jail | 60m Jail + Warn | Ban 2 - 4 Zile |
| **MetaGaming (MG)** | Warn | Warn + 60m Jail | Ban 3 - 7 Zile |
| **Cop Baiting** | Avertisment Verbal / 20m Jail | 40m Jail | Warn + 60m Jail |
| **Combat Logging (Alt+F4 în RP)** | Ban 3 Zile | Ban 5 Zile | Ban 7 - 14 Zile |
| **Olympic Swimming / Bunny Hop** | 20m Jail | 40m Jail | Warn |
| **Toxicitate OOC / Suferințe pe chat** | Mute 30m / Warn | Warn + Ban 24h | Ban 3 - 7 Zile |
| **Rasism / Discriminare / Injuri grave** | **Ban Permanent** | **Ban Permanent** | **Ban Permanent** |
| **Bug Abuse / Exploiting** | Ban 7 Zile + Wipe parțial | Ban 14 - 30 Zile + Wipe | **Ban Permanent** |
| **Cheats / Noclip / Aimbot / Mențiuni hack** | **Ban Permanent** | **Ban Permanent** | **Ban Permanent** |

---

### ⚠️ Sistemul de Avertismente (Warn-uri)

1. Un **Warn** rămâne activ pe cont timp de **30 de zile**.
2. **La acumularea a 3 Warn-uri active**, sistemul generează automat **BAN TEMPORAR timp de 7 ZILE**, iar la expirare warn-urile se resetează.
3. Dacă după expirarea ban-ului jucătorul revine și acumulează din nou 3 warn-uri în timp scurt, sancțiunea devine **Ban 30 de zile sau Permanent**.

---

### 🛡️ Cum se face un Ticket Corect & Procedura de Reclamație

{% hint style="warning" %}
* **Nu întrerupeți acțiunea în joc**: Chiar dacă celălalt jucător greșește (face VDM sau RDM), **finalizați scena de RP** sau așteptați să se încheie conflictul.
* Nu deschideți ticket pe `/report` cu mesaje de tip *"vino repede că e prost"* sau *"dă-i ban"*.
* Scrieți concis: `/report ID 45 posibilitate RDM la banca centrala, am filmare`.
* **Dovezile video sunt obligatorii**: Orice reclamație pentru DM, VDM, PG sau Fentare RP necesită o filmare de minim 1-2 minute din care să reiasă întregul context (folosind Medal.tv, OBS sau Nvidia Shadowplay).
{% endhint %}

---

### 🔓 Procedura de Cerere Unban

Dacă ai fost sancționat și consideri că măsura luată a fost nejustificată sau dorești o a doua șansă:
1. Accesează serverul de Discord **NewLife**: [discord.gg/newliferp](https://discord.gg/newliferp).
2. Mergi pe canalul dedicat `#cereri-unban`.
3. Completează formularul oficial respectând modelul:
   * **Nume Cont / Discord Tag:**
   * **Steam Hex / ID FiveM:**
   * **Administratorul care te-a sancționat:**
   * **Motivul sancțiunii:**
   * **Dovada / Argumentarea ta:**
   * **De ce consideri că meriți unban?**
4. Cererile de unban sunt analizate de Conducerea Staff-ului în termen de **24 - 48 de ore**.
