# Regulament Ilegalități & Jafuri

<h2 align="center"><mark style="color:red;"><strong>CADRUL ACTIVITĂȚILOR ILEGALE - NEWLIFE</strong></mark></h2>

***

Activitățile ilegale (jafuri, atacuri armate, răpiri, trafic de substanțe) sunt reglementate strict pentru a menține un echilibru între forțele de ordine și grupările infracționale.

---

### <mark style="color:yellow;">**1. Delimitarea Hărții pe Zone**</mark>

{% hint style="success" icon="shield-check" %}
## 🟢 Zona Sigură (SafeZone / GreenZone)
**Locații:** Spital Central (SMURD), Secții de Poliție, Primărie / Job Center, Locații de spawn, Service-uri auto oficiale, Reprezentanțe auto și locațiile de joburi legale pentru începători.
* În aceste zone este **strict interzisă** orice activitate ilegală: jafuri, bătăi, scoatere de arme, răpiri sau furt de mașini.
* Este interzis să fugi într-un SafeZone în timpul unei urmăriri de poliție sau conflict armat (**Refuz RP prin SafeZone**).
{% endhint %}

{% hint style="info" icon="building" %}
## ⚪ Zona Publică (Orașul Central)
**Locații:** Bulevardele principale, piețele comerciale, zonele rezidențiale centrale.
* Jefuirea sau răpirea persoanelor pe stradă în văzul lumii este **interzisă**.
* Folosirea armelor de foc pe timp de zi (08:00 - 21:00) este interzisă, cu excepția cazurilor de autoapărare legitimă cu pistol autorizat.
* În intervalul de noapte (21:00 - 06:00), sunt permise conflicte restrânse doar în ganguri, parcări subterane și acoperișuri, cu motive bine întemeiate.
{% endhint %}

{% hint style="warning" icon="map-pin" %}
## 🟡 Zona Retrasă (Periferii & Zone Industriale)
**Locații:** Sandy Shores, Grapeseed, portul industrial, depozite părăsite, șantiere și zone montane.
* Sunt permise acțiuni ilegale, schimburi clandestine și răpiri.
* Armele de calibru mic și mediu pot fi utilizate cu motive bine întemeiate.
* Poliția poate efectua patrule sporite și legitimări ale persoanelor mascate.
{% endhint %}

{% hint style="danger" icon="skull" %}
## 🔴 Zona Rău Famată (Ghetouri & Turf-uri Mafiote)
**Locații:** South Central, Davis, Chamberlain Hills, Barrio, zonele oficiale de cartier ale mafiilor.
* Poliția are dreptul de a legitima și percheziționa orice persoană mascată sau suspectă în orice moment.
* Conflictele armate între grupări rivale sunt permise la orice oră, cu respectarea regulilor de turf.
* Civilii care intră neînsoțiți în aceste cartiere își asumă riscul de a fi jefuiți sau agresați.
{% endhint %}

---

### <mark style="color:yellow;">**2. Regulamentul Jafurilor Oficiale**</mark>

Toate jafurile mari trebuie să aibă loc cu respectarea numărului de participanți și a regulilor de negociere:

| Tip Jaf | Min/Max Atacatori | Min/Max Polițiști | Număr Ostatici | Nivel Dificultate |
| :--- | :---: | :---: | :---: | :---: |
| **Magazin 24/7** | 2 - 4 | 2 - 4 | 1 | Ușor |
| **Bijuterie (Vangelico)** | 3 - 5 | 3 - 6 | 1 - 2 | Mediu |
| **Bancă Mică (Fleeca)** | 3 - 6 | 4 - 8 | 1 - 3 | Dificil |
| **Banca Centrală (Pacific)**| 5 - 8 | 6 - 12 | 2 - 4 | Extrem |
| **Iaht de Lux / Transport Valori** | 4 - 7 | 5 - 10 | 1 - 2 | Dificil |

{% hint style="warning" %}
**Reguli Esențiale pentru Jafuri:**
1. **Ostatici Reali**: Ostaticii trebuie să fie jucători reali găsiți IC pe parcursul roleplay-ului. Este **strict interzis** să folosiți prieteni sau membri din propria mafie pe post de "ostatic fals" (**Fail RP**).
2. **Viața Ostaticului**: Poliția este obligată să pună viața ostaticului pe primul loc. Dacă atacatorii au ostatic și nu au deschis focul, forțele speciale nu vor asalta imediat clădirea, ci vor iniția negocieri.
3. **Revendicări Permise**:
   * Trecere liberă către vehicule (Free Passage) și fără urmărire cu elicopterul în primele 30 de secunde (pentru bănci mari).
   * Schimb de ostatici contra timp suplimentar de deschidere seif.
4. **Revendicări Interzise**:
   * Nu se pot cere bani de la poliție pentru viața ostaticului.
   * Nu se pot cere mașini sau arme ale forțelor de ordine.
   * Nu se poate cere polițiștilor să se predea sau să își dea jos armura.
{% endhint %}

---

### <mark style="color:yellow;">**3. Răpiri și Cereri de Răscumpărare**</mark>

* Răpirea unui civil este permisă doar în zone retrase sau rău famate, de către un grup de **minim 2 persoane înarmate**.
* Jucătorul răpit nu poate fi forțat să își retragă toți banii din bancă sau să își vândă mașinile.
* **Suma maximă ce poate fi jefuită de la un civil pe loc:** 15.000$ (bani cash din buzunar).
* În cazul răpirii unui membru al forțelor de ordine sau al unui lider mafiot, răscumpărarea cerută instituției/familiei nu poate depăși **100.000$**.
* După primirea răscumpărării, persoana răpită **trebuie eliberată în viață**. Uciderea ostaticului după plata sumei se consideră Rob & Kill.

---

### <mark style="color:yellow;">**4. Războaie între Mafii & Drive-by**</mark>

* **Declanșarea Războiului**: Un război între două familii/mafii oficiale poate fi declarat doar pe baza unui roleplay consistent (trădare, furt masiv de teritoriu) și trebuie notificat către Staff pe canalul de conducere facțiuni.
* **Ținută Distintivă**: Fiecare mafie este obligată să poarte culorile specifice sau măștile caracteristice în timpul acțiunilor armate, pentru identificare vizuală.
* **Drive-by (Trageri din mașină)**:
  * Șoferul vehiculului **nu are voie să tragă** în timp ce conduce mașina.
  * Tragerile din vehicul se fac doar de către pasageri, la viteze reduse (sub 80 km/h).
  * Folosirea armelor de calibru greu (lunete, mitraliere grele) din interiorul mașinii este interzisă.
