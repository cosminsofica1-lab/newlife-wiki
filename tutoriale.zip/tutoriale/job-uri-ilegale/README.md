# Job-uri Ilegale & Lumea Subterană

<h2 align="center"><mark style="color:red;"><strong>RISCURI MARI, CÂȘTIGURI URIAȘE</strong></mark></h2>

***

Joburile ilegale din **NewLife** oferă posibilitatea de a strânge averi considerabile într-un timp scurt, însă vin la pachet cu pericole constante: intervenția agenților DIICOT/Poliției, ambuscade din partea mafiilor rivale și riscul de a petrece ani grei după gratiile închisorii Bolingbroke.

---

### ⚠️ Reguli de Aur pentru Ilegaliști

{% hint style="danger" %}
1. **Fără mască în SafeZone**: Nu purtați cagulă sau armă la vedere în zonele sigure. Poliția vă va percheziționa imediat.
2. **Zonele de Tranzacție**: Punctele de procesare și vânzare a drogurilor și contrabandei sunt plasate în afara orașului sau în cartiere rău famate. Orice tranzacție poate fi interceptată de informatori.
3. **Poliția este alertată prin dispatch**: Anumite acțiuni (spargerea ușii unui garaj, furtul de cabluri electrice sau tranzacțiile de droguri) pot declanșa alerte sonore la dispeceratul poliției!
{% endhint %}

---

### 📋 Prezentare Generală a Activităților Ilegale

| Activitate | Risc Poliție | Investiție Inițială | Câștig Potențial |
| :--- | :---: | :---: | :---: |
| **Traficant de Țigări** | Scăzut | Mică (Portbagaj încăpător) | 10.000$ - 18.000$ |
| **Miner Ilegal** | Mediu | Târnăcop + Mască de gaz | 15.000$ - 28.000$ |
| **Spărgător de Garaje** | Mediu spre Ridicat | Set Șperacle + Lampă | 20.000$ - 40.000$ |
| **Traficant de Droguri** | Ridicat | Cântar, pungi, laborator | 35.000$ - 80.000$ |
| **Traficant de Arme** | Extrem | Licențe false, atelier secret | 60.000$ - 150.000$ |
