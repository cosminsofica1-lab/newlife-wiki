# Job Ilegal: Traficant de Țigări

<h2 align="center"><mark style="color:red;"><strong>CONTRABANDĂ CU TUTUN NETIMBRAT</strong></mark></h2>

***

Contrabanda cu țigări aduse cu barca pe timp de noapte este o metodă rapidă și cu risc moderat de a câștiga bani lichizi, evitând taxele vamale ale statului.

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Preluare Marfă:** Mergi noaptea pe plajele izolate din Paleto Cove sau Catfish View unde acostează bărcile de contrabandă.
2. **Încărcare Baloți:** Preia cartușele de țigări netimbrate și ascunde-le în portbagajul și bancheta din spate a mașinii tale.
3. **Transportul:** Evită filtrele de poliție de pe autostrada Senora Freeway! Condu pe drumurile forestiere sau secundare.
4. **Distribuție la Chioșcuri:** Vinde baxurile de țigări către patronii magazinelor de cartier din ghetou la jumătate de preț.

---

### 💰 Câștiguri

* **Câștig estimat:** `10.000$ - 18.000$` per transport complet.
