# Job Ilegal: Traficant de Arme

<h2 align="center"><mark style="color:red;"><strong>ASAMBLAREA ȘI COMERȚUL CLANDESTIN DE ARMAMENT</strong></mark></h2>

***

Traficul de armament este activitatea cu cel mai mare risc de pe serverul **NewLife**, fiind controlat exclusiv de marile carteluri și sindicate mafiote.

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Obținerea Componentelor:**
   * Pentru asamblarea unei arme letale (Glock 17, Combat Pistol, Micro SMG, AK-47) ai nevoie de piese individuale: *țeavă de oțel, mecanism trăgaci, arc recuperator, percutor și corp de armă*.
   * Aceste piese se găsesc prin interceptarea convoaielor militare clandestine, jafuri de depozite sau din lăzile ascunse în ape adânci.
2. **Atelierul Clandestin (Buncăr):**
   * Într-un atelier secret neînregistrat la primărie, folosește bancul de lucru (`Workbench`) pentru a asambla armele și a ștanța serii false.
   * Fabrică muniție turnând plumb și capsule detonante.
3. **Vânzare Către Mafii & Clienți:**
   * Armele se vând discret prin intermediul canalelor securizate DarkWeb (`/anon`) sau întâlniri față în față în locații izolate cu pază armată.

---

### 💰 Câștiguri & Consecințe

* **Câștig:** `60.000$ - 150.000$` per lot de armament complet asamblat.
* **Avertisment DIICOT:** Prinderea cu armament de asalt fără serie atrage **70.000$ amendă**, **60 luni închisoare** și posibilitatea de a primi **Character Kill (CK)** dacă refuzi să colaborezi în fața instanței!
