# Job Ilegal: Miner Ilegal

<h2 align="center"><mark style="color:red;"><strong>EXTRACȚIA SUBSTANȚELOR RADIOACTIVE ȘI PĂMÂNTURILOR RARE</strong></mark></h2>

***

Spre deosebire de cariera legală de piatră, **Mineritul Ilegal** se desfășoară în galeriile părăsite adânci și neventilate de sub Muntele Chiliad sau minele abandonate din deșert.

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Echipament Obligatoriu:** Ai nevoie de o **Mască de Gaze** (cumpărată de la Black Market), altfel vei inhala vapori toxici și vei leșina în galerie!
2. **Intrarea în Mina Clandestină:** Găsește intrarea secretă camuflată printre stânci.
3. **Extragerea Uraniului & Litiului:**
   * Sparge filoanele strălucitoare verzi/albastre cu un târnăcop din oțel călit.
   * Depozitează minereul radioactiv în butoaie plumbuite.
4. **Ieșirea și Vânzarea:**
   * Încarcă marfa în portbagaj și mergi la Cumpărătorul Clandestin din Portul Militar părăsit.
   * Banii primiți sunt cash nereglementat.

---

### 💰 Câștiguri

* **Câștig estimat:** `15.000$ - 28.000$` per sac de uraniu/litiu rafinat.
