# Job Ilegal: Spărgător de Garaje

<h2 align="center"><mark style="color:red;"><strong>FORȚEAZĂ UȘI DE GARAJ ȘI SUSTRAGE PIESE AUTO SCUMPE</strong></mark></h2>

***

Spargerea garajelor din cartierele înstărite (Vinewood Hills, Rockford Hills) este o activitate nocturnă rentabilă pentru hoții specializați în mecanică și electronică auto.

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Unelte Necesare:** Cumpără de la piața neagră:
   * Set de șperacle (Lockpicks)
   * Dispozitiv de decodat alarme (Signal Hacker)
   * Lanternă și rangă
2. **Identificarea Țintei:** Mergi noaptea printre vilele de lux și verifică porțile automate de garaj (`tasta E`).
3. **Spargerea:**
   * Rezolvă minijocul de descuiere a yalei mecanice fără a rupe șperaclul.
   * Dezactivează alarma în maxim 15 secunde; dacă greșești, alarma sonoră va trimite un apel de urgență automat la Poliție!
4. **Furtul:**
   * Demonțează jantele de magneziu, casetofoanele scumpe, trusele de scule și bateriile găsite în garaj.
5. **Vânzare la Dezmembrări:** Du componentele furate la cimitirul de mașini (Scrapyard) pentru valorificare imediată.

---

### 💰 Câștiguri

* **Câștig estimat:** `20.000$ - 40.000$` pe noapte de spargeri.
