# Job Ilegal: Traficant de Droguri

<h2 align="center"><mark style="color:red;"><strong>PRODUCȚIA, PROCESAREA ȘI DISTRIBUȚIA PE STRĂZI</strong></mark></h2>

***

Traficul de substanțe interzise este cea mai profitabilă ramură a lumii interlope din **NewLife**. Există mai multe tipuri de substanțe: **Marijuana**, **Cocaină** și **Metamfetamină**.

---

### 🌿 1. Marijuana (Cânepă)

1. **Recoltare:** Mergi la plantația secretă ascunsă pe dealurile din Mount Chiliad sau Sandy Shores. Culege mugurii maturi (`tasta E`).
2. **Uscare & Ambalare:** La laboratorul improvizat sau în rulotă, usucă frunzele și ambalează-le în plicuri de 10g (ziplock).
3. **Vânzare (Cornering):**
   * Mergi pe străzile cartierelor rău famate (South Central, Davis).
   * Apropie-te de NPC-uri (civili de pe stradă) și apasă `E` pentru a le oferi marfa.
   * *Atenție:* Unii cetățeni pot refuza și pot suna la 911! Dacă auzi sirenele, părăsește rapid zona.

---

### ❄️ 2. Cocaină & Metamfetamină

* **Cocaină:** Necesită culegerea frunzelor de coca, combinarea cu acid chimic și presarea în cărămizi de cocaină pură.
* **Metamfetamină:** Se prepară în rulote speciale folosind efedrină și azotat. Fii atent la temperatura cazanului: o greșeală poate provoca o explozie a laboratorului!
* **Distribuție En-gros:** Mafiile mari pot vinde cantități mari de droguri către cumpărători internaționali în port, obținând sute de mii de dolari cash nespălat.

---

### 💰 Câștiguri & Riscuri

* **Câștig:** `35.000$ - 80.000$` per transport/tură completă.
* **Risc Penal:** Conform Codului Penal (Art. 24), traficul atrage **50.000$ amendă** și **55 luni de închisoare** + confiscarea totală a mărfii și vehiculului!
