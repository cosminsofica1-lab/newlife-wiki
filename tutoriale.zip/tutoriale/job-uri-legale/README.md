# Job-uri Legale

<h2 align="center"><mark style="color:green;"><strong>CARIERA TA ÎN ORAȘUL NEWLIFE</strong></mark></h2>

***

Joburile legale reprezintă modalitatea ideală și sigură pentru cetățenii cinstiți de a câștiga primii bani, de a-și cumpăra prima locuință și de a investi în mașini personale fără riscul de a fi arestați de poliție.

---

### 🏢 Cum te angajezi la un Job Legal?

1. Deschide harta (`ESC` sau `P`) și caută pictograma galbenă **Job Center / Primărie** (centrul orașului).
2. Mergi la ghișeu și interacționează cu meniul de angajări (`tasta E`).
3. Alege meseria dorită și semnează contractul de muncă.
4. Pe hartă îți va apărea automat un nou punct de reper către vestiarul sau sediul firmei respective.
5. Mergi la vestiar, îmbracă uniforma de serviciu, preia cheile vehiculului de muncă și începe traseul!

---

### 📊 Tabel Comparativ Joburi Legale

| Job | Dificultate | Câștig Mediu / Cursă | Nivel Necesar | Vehicul Oferit |
| :--- | :---: | :---: | :---: | :---: |
| **Salubrizare** | Foarte Ușor | 3.500$ - 5.000$ | Nivel 1 | Măturătoare Stradală |
| **Poștaș** | Ușor | 4.000$ - 6.500$ | Nivel 1 | Dubă Poștă (Boxville) |
| **Glovo / Livrator** | Ușor | 4.500$ - 7.000$ | Nivel 1 | Scooter / Mașină mică |
| **Miner** | Mediu | 6.000$ - 9.500$ | Nivel 2 | Basculantă Tipper |
| **Electrician** | Mediu | 5.500$ - 8.500$ | Nivel 2 | Utilitară Burrito |
| **Pescar** | Relaxant | 5.000$ - 11.000$ | Nivel 1 | Barcă / Dinghy |
| **Tăietor Lemne** | Mediu | 7.000$ - 10.500$ | Nivel 2 | Camion Lemne |
| **Camionagiu** | Avansat | 9.000$ - 16.000$ | Nivel 3 | Tir Phantom / Hauler |

---

### 💡 Sfaturi pentru Jucători la Început

{% hint style="tip" %}
* **Folosește centura de siguranță (`tasta K`)**: În caz de accident în timpul muncii, nu vei fi aruncat prin parbriz și nu riști să ajungi în comă.
* **Respectă regulile de circulație**: Autospecialele de serviciu pot fi oprite de poliție dacă treci pe roșu sau mergi cu viteză pe trotuar.
* **Progresul în Nivel (Leveling)**: Pe măsură ce finalizezi comenzi și ture de lucru, vei acumula puncte de experiență (XP) care îți vor debloca bonusuri financiare și vehicule mai rapide!
{% endhint %}
