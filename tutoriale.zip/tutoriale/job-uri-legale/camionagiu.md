# Job Legal: Camionagiu

<h2 align="center"><mark style="color:green;"><strong>STĂPÂNEȘTE AUTOSTRĂZILE DIN NEWLIFE</strong></mark></h2>

***

Jobul de **Camionagiu** (Trucker) este cel mai bine plătit job legal de pe server, ideal pentru iubitorii de tiruri și transporturi de marfă pe distanțe lungi (Los Santos - Paleto Bay).

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Depozitul Logistic:** Mergi la Portul Los Santos sau la Depozitul Logistic din nord.
2. **Contractul de Livrare:**
   * Deschide panoul de comenzi logistice.
   * Alege tipul de marfă (Materiale de Construcții, Alimente Congelate, Combustibil Inflamabil, Piese Auto).
3. **Cuplare Remorcă:**
   * Scoate capul-tractor din garaj.
   * Manevrează cu spatele cu grijă și cuplează semiremorca indicată.
4. **Transportul:**
   * Conduce prudent pe autostradă, respectând limitele de viteză și gabaritul vehiculului.
   * Oprește la cântarele autorizate dacă ești somat de Poliția Rutieră.
5. **Descărcare & Plata:**
   * Parchează remorca cu spatele la rampa de descărcare a magazinului sau a fabricii de destinație.
   * Semnează avizul de expediție și încasează contravaloarea cursei.

---

### 💰 Câștiguri & Sfaturi

* **Câștig estimat per cursă lungă:** `9.000$ - 16.000$`
* **Atenție la avarii:** Dacă răstorni remorca sau avariezi grav încărcătura, firma logistică îți va reține penalizări din salariu!
