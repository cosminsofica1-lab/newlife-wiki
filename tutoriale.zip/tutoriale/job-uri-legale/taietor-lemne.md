# Job Legal: Tăietor de Lemne (Lumberjack)

<h2 align="center"><mark style="color:green;"><strong>PRELUCREAZĂ BUȘTENII ÎN PĂDURILE PALETO</strong></mark></h2>

***

Jobul de **Tăietor de Lemne** se desfășoară în aerul curat al pădurilor din Paleto Bay și Muntele Chiliad, reprezentând principala sursă de cherestea pentru atelierele de tâmplărie din NewLife.

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Locația:** Mergi la Fabrica de Cherestea din Paleto Forest.
2. **Echipare:** Ia drujba profesională și hainele de protecție împotriva așchiilor.
3. **Tăierea Arborilor:**
   * Găsește copacii marcați de ocolul silvic pentru defrișare controlată.
   * Pornește drujba (`tasta E`) și debitează bușteanul în trunchiuri manevrabile.
4. **Încărcare & Transport:**
   * Încarcă buștenii în remorca camionului forestier.
   * Transportă încărcătura la gaterul automat pentru transformare în scânduri finisate.
5. **Vânzare:** Cheresteaua se vinde la Depozitul de Construcții sau direct jucătorilor care își mobilează casele.

---

### 💰 Câștiguri

* **Câștig estimat:** `7.000$ - 10.500$` per transport complet.
