# Job Legal: Pescar

<h2 align="center"><mark style="color:green;"><strong>PESCUIEȘTE ÎN LARGUL OCEANULUI ȘI VINDE LA PIAȚĂ</strong></mark></h2>

***

Jobul de **Pescar** oferă o experiență relaxantă, perfectă pentru momentele în care vrei să asculți valurile oceanului și să prinzi pești exotici sau crustacee de valoare mare.

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Magazinul de Pescuit:** Mergi pe pontonul Del Perro Pier sau în Port și cumpără o undiță profesională și momeală (râme, creveți, peștișori).
2. **Locația de Pescuit:**
   * Poți pescui de pe mal, de pe pontoane sau poți închiria o barcă pentru a pescui în largul apelor adânci.
3. **Procesul de Pescuit:**
   * Deschide inventarul (`F2`) și dă "Folosește" pe undiță.
   * Așteaptă până când pluta este trasă la fund.
   * Apasă tastele indicate în minijocul de mulinare pentru a nu rupe firul.
4. **Captura:** Peștii prinși (Păstrăv, Somn, Biban, Ton, Rechin Mic) ajung direct în juvelnic/inventar.
5. **Vânzarea:** Mergi la Piața de Pește sau la Restaurantele din port pentru a-ți vinde prada proaspătă la prețuri competitive!

---

### 💰 Câștiguri

* **Câștig estimat:** `5.000$ - 11.000$` per sesiune de pescuit (în funcție de raritatea peștilor prinși).
* **Capturi rare:** Ai șansa de a agăța perle negre sau cufere vechi pierdute pe fundul apei!
