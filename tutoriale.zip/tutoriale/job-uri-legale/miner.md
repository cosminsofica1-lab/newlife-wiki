# Job Legal: Miner

<h2 align="center"><mark style="color:green;"><strong>EXTRAGE MINEREURI ȘI METAL PREȚIOS</strong></mark></h2>

***

Jobul de **Miner** este o activitate fizică intensă, ideală pentru jucătorii care vor să producă materie primă (fier, cupru, aur, diamante) necesară mecanicilor și magazinelor de bijuterii.

---

### 📍 Pas cu Pas: Desfășurarea Muncii

1. **Locația:** Mergi la cariera de piatră din Davis Quartz (zona de nord-est a hărții).
2. **Echipament:** Preia casca de protecție cu lanternă și un târnăcop sau un ciocan pneumatic din magazinul minei.
3. **Extracție:**
   * Apropie-te de stâncile marcate cu filoane minerale.
   * Apasă `E` și finalizează minijocul de sincronizare pentru a sparge roca.
4. **Spălare & Sortare:**
   * Transportă bolovanii la banda de spălare și sitare a pietrișului.
   * Separă minereul brut de impurități.
5. **Topire & Rafinare:**
   * La furnalul industrial, topește minereul obținând lingouri de fier, cupru sau aur.
6. **Vânzare:** Vinde lingourile la trader-ul de metale sau direct mecanicilor și jucătorilor la un preț negociat!

---

### 💰 Câștiguri & Rentabilitate

* **Câștig estimat:** `6.000$ - 9.500$` per tură completă de rafinare.
* **Șansă de pietre prețioase:** În timpul spălării pietrișului, ai o șansă de 5-10% să găsești rubine sau diamante brute, ce pot fi vândute la bijuterie pentru sume impresionante!
