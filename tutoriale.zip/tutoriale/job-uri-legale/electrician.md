# Job Legal: Electrician

<h2 align="center"><mark style="color:green;"><strong>REPARĂ REȚEAUA ELECTRICĂ A ORAȘULUI</strong></mark></h2>

***

Meseria de **Electrician** combină conducerea utilitarei prin oraș cu minijocuri logice de conectare a firelor și resetare a panourilor electrice de înaltă tensiune.

---

### 📍 Pas cu Pas: Desfășurarea Muncii

1. **Sediul Firmei Electrice:** Localizează depozitul *Darnell Power* marcat pe hartă.
2. **Preluare Utilitară:** Ia duba de serviciu echipată cu scule speciale și scară extensibilă.
3. **Intervenții la Defecțiuni:**
   * GPS-ul îți va trimite alerte de avarii la stâlpii stradali sau cutiile de distribuție ale blocurilor.
   * Conduce până la panoul defect.
   * Coboară, deschide panoul (`tasta E`) și rezolvă minijocul electric (conectează cablurile de aceeași culoare și evită scurtcircuitul).
4. **Recompensă:** Fiecare panou reparat repornește iluminatul zonei și îți transferă automat banii în cont.

---

### 💰 Câștiguri

* **Câștig estimat:** `5.500$ - 8.500$` per tură (5 avarii remediate).
* **Skill special:** Electricienii cu experiență pot debloca ulterior unelte de crafting avansat pentru kituri de hacking auto.
