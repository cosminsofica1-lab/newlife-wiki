# Job Legal: Salubrizare

<h2 align="center"><mark style="color:green;"><strong>CURĂȚĂ ORAȘUL ȘI CÂȘTIGĂ BANI CINSTIȚI</strong></mark></h2>

***

Jobul de **Salubrizare** este cel mai accesibil job de început pe **NewLife**, perfect pentru noii veniți care doresc să descopere străzile orașului și să strângă primii bani de haine și hrană.

---

### 📍 Pas cu Pas: Cum Începi Munca

1. **Angajare:** Mergi la Job Center și alege opțiunea **Salubrizare / Gunoier**.
2. **Sediul Firmei:** Urmează marcajul verde de pe hartă până la Depozitul Central de Salubritate din zona industrială de sud.
3. **Echipare:** Apasă tasta **`E`** la vestiar pentru a îmbrăca vesta reflectorizantă și mănușile de protecție.
4. **Preluare Autospecială:** Mergi la garajul exterior și scoate autospeciala de salubritate.
5. **Traseul:** Urmează punctele de colectare afișate pe mini-map:
   * Oprește vehiculul lângă pubele.
   * Coboară și apasă `E` pentru a ridica sacii menajeri.
   * Încarcă deșeurile în compactorul din spatele mașinii.
6. **Finalizare & Salariu:** După completarea tuturor punctelor (de regulă 8 - 12 opriri), revino la depozit, parchează vehiculul și primește banii direct în buzunar sau pe card!

---

### 💰 Câștiguri & Beneficii

* **Câștig estimat per tură:** `3.500$ - 5.000$`
* **Timp mediu per tură:** `8 - 10 minute`
* **Bonus de echipă:** Dacă lucrezi cu un prieten (unul conduce, altul încarcă pubelele), timpul se reduce la jumătate!
