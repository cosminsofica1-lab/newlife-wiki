# Job Legal: Poștaș

<h2 align="center"><mark style="color:green;"><strong>LIVREAZĂ CORESPONDENȚA ȘI COLETELE ÎN NEWLIFE</strong></mark></h2>

***

Jobul de **Poștaș** (Postman) este o meserie relaxantă, ideală pentru cei cărora le place să conducă dube prin cartierele rezidențiale și să împartă scrisori și pachete.

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Sediul Poștei:** Localizează depozitul *GoPostal* sau *PostOP* marcat pe hartă.
2. **Îmbrăcăminte & Vehicul:** Schimbă-te în uniforma de poștaș și scoate duba albastră din garaj.
3. **Încărcare Pachete:** Mergi în spatele depozitului și preia coletele din zona de sortare (`tasta E`).
4. **Traseul de Livrare:**
   * GPS-ul îți va genera adrese ale caselor din Los Santos sau suburbii.
   * Oprește duba în siguranță pe marginea carosabilului.
   * Deschide ușile din spate (`tasta L`), ia pachetul în brațe și lasă-l în cutia poștală a casei indicate.
5. **Încasare Salariu:** Fiecare colet livrat îți aduce un bonus instant, iar la finalul turei primești plata integrală a contractului.

---

### 💰 Câștiguri & Sfaturi

* **Câștig estimat per tură:** `4.000$ - 6.500$`
* **Tips:** Clienții mulțumiți îți pot oferi bacșiș generos generat aleatoriu la fiecare livrare reușită!
