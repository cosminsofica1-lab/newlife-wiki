# Job Legal: Glovo & Livrator

<h2 align="center"><mark style="color:green;"><strong>LIVREAZĂ MÂNCARE CALDĂ ȘI COLETE RAPIDE</strong></mark></h2>

***

Jobul de **Livrator Glovo** este dinamic, perfect pentru cei care iubesc să se strecoare pe două roți sau cu mașini de oraș prin traficul aglomerat din Los Santos.

---

### 📍 Pas cu Pas: Desfășurarea Activității

1. **Sediul Glovo:** Mergi la hub-ul de curierat marcat pe hartă în zona centrală.
2. **Preluare Scooter / Rucsac:** Echipează rucsacul termic galben/verde și scoate scooterul Faggio din garaj (sau folosește mașina personală înregistrată).
3. **Preluare Comandă:**
   * Deschide aplicația pe telefon (`F1 -> Glovo Courier`) și acceptă o comandă de la un restaurant partener (Burgershot, Pizza This, Up-n-Atom).
   * Condu la restaurant și preia pachetul cald de la tejghea.
4. **Livrare la Ușa Clientului:**
   * Urmează traseul GPS până la apartamentul sau vila clientului.
   * Sună la interfon (`tasta E`) și înmânează mâncarea.
5. **Câștig:** Salariul de bază intră automat pe card, iar clienții generoși lasă bacșiș cash generos în funcție de cât de repede ai ajuns!

---

### 💰 Câștiguri

* **Câștig estimat:** `4.500$ - 7.000$` per tură de 4 - 5 comenzi.
