# Comenzi & Controale

<h2 align="center"><mark style="color:blue;"><strong>GHIDUL TASTELOR ȘI COMENZILOR PE NEWLIFE</strong></mark></h2>

***

### ⌨️ Taste Rapide & Comenzi Esențiale

| Tastatură | Funcție în Joc | Descriere |
| :---: | :--- | :--- |
| **`F1`** | **Telefon Mobil** | Accesează apeluri, mesaje, GPS, Twitter/LifeInvader, transferuri bancare și cameră foto |
| **`F2`** | **Inventar Personal** | Deschide ghiozdanul/buzunarele, permite folosirea sau mutarea itemelor și a armelor |
| **`F3`** | **Meniu Animații (Emotes)** | Sute de animații împărțite pe categorii (dansuri, posturi de stat, fumat, saluturi) |
| **`F5` / `M`** | **Meniu Interacțiune / Radial** | Meniu circular pentru controlul mașinii (motor, uși, portbagaj), legitimație, buletin |
| **`F6`** | **Meniu Facțiune** | Deschide panoul de serviciu pentru Polițiști, Medici, Mecanici (încătușare, facturi) |
| **`F7`** | **Facturi & Datorii** | Vizualizează și plătește amenzile de circulație sau facturile primite de la mecanici |
| **`K`** | **Centură de Siguranță** | Pune sau scoate centura în mașină (te protejează la impacte majore) |
| **`B`** | **Arată cu Degetul** | Animație rapidă de indicare a unei direcții sau a unui obiect |
| **`X`** | **Mâinile Sus / Jos** | Folosit în scenarii de jaf, arestare sau capitulare |
| **`U`** | **Blocare / Deblocare Vehicul** | Încuie sau descuie mașina personală de la distanță mică |
| **`L`** | **Portbagaj / Deschidere Cheie** | Deschide depozitul mașinii dacă ești poziționat în spatele acesteia |
| **`T`** | **Deschidere Chat** | Deschide bara de comenzi text și roleplay |

---

### 💬 Comenzi de Roleplay pe Chat

{% hint style="info" %}
Comenzile de text sunt sufletul jocului de rol pe FiveM. Folosește-le corect pentru a descrie acțiunile complexe care nu au o animație gata pregătită în joc.
{% endhint %}

#### 1. Comanda `/me`
* **Utilizare:** Descrie o acțiune fizică efectuată de personajul tău.
* **Exemple corecte:**
  * `/me își scoate portofelul din buzunarul interior al sacoului și înmânează permisul`
  * `/me verifică pulsul persoanei întinse pe asfalt la nivelul arterei carotide`
  * `/me ia un șomoiog de vată sterilă și aplică dezinfectant pe rană`

#### 2. Comanda `/do`
* **Utilizare:** Descrie mediul înconjurător, starea fizică a personajului sau adresează o întrebare descriptivă unui alt jucător.
* **Exemple corecte:**
  * `/do Se simte un miros puternic de benzină în urma impactului.`
  * `/do Ce se poate observa în portbagajul mașinii la deschidere?`
  * `/do Se simte pulsul victimei?`
* *Răspunsul obligatoriu:* `/do Pulsul este slab și neregulat.`

#### 3. Comanda `/doc` (Doctor / Timp de așteptare)
* Folosită în special de medici sau mecanici pentru contorizarea unei acțiuni minuțioase:
  * `/doc 1/5`, `/doc 2/5` ... până la `/doc 5/5` pentru simularea unei intervenții chirurgicale sau schimbarea unui motor.

#### 4. Comanda `/try`
* Simulează o acțiune cu rezultat imprevizibil (șansă de 50% reușită / eșec):
  * `/try să spargă lacătul vechi cu o rangă de fier` (Rezultat: *Reușit* sau *Eșuat*).

---

### 🛠️ Comenzi Generale & Administrative

* **`/report [mesaj]`**: Trimite un apel de urgență către echipa de admini online dacă ești victima unei încălcări de regulament.
* **`/help`**: Deschide ghidul rapid cu cele mai utile comenzi din joc.
* **`/id`**: Afișează ID-ul tău temporar de pe sesiune.
* **`/pay [ID] [Sumă]`**: Transferă bani cash direct jucătorului din imediata ta apropiere.
* **`/giveitem [ID]`**: Înmânează un obiect din inventar persoanei din fața ta.
* **`/tweet [mesaj]`**: Trimite un mesaj public pe rețeaua socială a serverului (vizibil tuturor pe ecran).
* **`/anon [mesaj]`**: Trimite un anunț anonim pe DarkWeb (disponibil doar pentru joburi ilegale / mafii).
