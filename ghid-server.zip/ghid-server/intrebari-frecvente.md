# Întrebări Frecvente (FAQ)

<h2 align="center"><mark style="color:blue;"><strong>TOT CE TREBUIE SĂ ȘTII DESPRE NEWLIFE</strong></mark></h2>

***

### 👑 Cine face parte din conducerea comunității?

{% hint style="info" icon="crown" %}
* **Fondator:** <mark style="color:blue;">**Cosmin**</mark>
* **Co-Fondator:** <mark style="color:blue;">**Echipa NewLife**</mark>
* **Lead Developer:** <mark style="color:blue;">**Development Team NewLife**</mark>
* **Head of Staff:** <mark style="color:blue;">**Management Staff**</mark>
{% endhint %}

---

### 🌐 Cum mă pot conecta pe serverul NewLife?

{% hint style="success" icon="globe" %}
Există 3 modalități simple de conectare:
1. **Direct prin Consola F8 (Cea mai rapidă metodă):**
   * Deschide FiveM, apasă tasta **F8** și tastează:
     ```bash
     connect fivem.newlife-rp.ro
     ```
2. **Prin Conexiune IP / Port:**
   * În consola F8 poți tasta direct IP-ul dedicat al serverului (anunțat pe Discord în `#anunturi-importante`).
3. **Prin Căutare în Server List:**
   * În FiveM la secțiunea *Play*, scrie la căutare `NewLife Romania` sau `NewLife Roleplay`.
{% endhint %}

---

### 🎮 Ce stil de roleplay și ce economie are serverul?

{% hint style="info" %}
* **Stil Roleplay:** **Medium - Hard RP (75 - 80%)**
  * Ne concentrăm pe calitatea interacțiunilor, replici credibile, dezvoltarea personajelor pe termen lung și diminuarea mentalității toxice de tip „shoot-to-win”.
* **Economie Realistă & Echilibrată:**
  * Economia este adaptată astfel încât o mașină normală să poată fi cumpărată după câteva zile de muncă la joburile legale, în timp ce supercar-urile, vilele de lux și armamentul greu reprezintă bunuri exclusive ce necesită efort susținut sau succes în lumea interlopă.
{% endhint %}

---

### 📱 Cum funcționează comunicarea vocală (Voice Chat)?

* Serverul folosește sistemul de voce integrat **pma-voice** (3D Spatial Audio).
* Nu este necesar un plugin extern (TeamSpeak sau TokoVOIP).
* **Taste esențiale voce:**
  * Schimbare distanță voce (Șoaptă - 1.5m / Normal - 5m / Strigăt - 15m): tasta **`H`** sau **`F11`** (configurabil).
  * Radio / Stație: tasta **`Caps Lock`** (sau buton lateral pe mouse).

---

### 💥 Ce fac dacă iau crash în timpul unei acțiuni de roleplay?

{% hint style="warning" %}
1. Redeschide imediat FiveM și reconectează-te pe server.
2. Intră pe serverul de Discord la canalul `#crash-roleplay`.
3. Postează mesajul: `Nume IC, ID, eram implicat în urmărire/jaf la locația X, revin în 3 minute`.
4. Ai la dispoziție **10 minute** să revii în scenă pentru a nu fi sancționat cu Combat Logging.
{% endhint %}

---

### 🚓 Cum pot aplica la o facțiune legală (Poliție, SMURD, Mecanici)?

* Recrutările se desfășoară atât IC (prin anunțuri de angajare la radio/tweet) cât și pe forumul/Discord-ul oficial.
* Cerințe minime pentru facțiuni guvernamentale:
  * Minim 15 - 25 ore pe server.
  * Microfon funcțional și maturitate în comportament.
  * Cazier curat (fără condamnări penale grave în ultimele 7 zile).
  * Trecerea testului teoretic din legislație și cod penal.

---

### 💼 Cum îmi pot înființa o organizație sau o mafie?

1. Adună un grup de minim 4 - 6 persoane serioase cu povești de caractere legate între ele.
2. Deschide un ticket de tip `Propunere / Creare Organizație Ilegală` pe Discord.
3. Prezintă: numele grupării, lore-ul (povestea istorică), sediul dorit pe hartă și ținutele reprezentative.
4. Conducerea va aproba perioada de probă (14 zile), timp în care activitatea voastră va fi monitorizată de adminii responsabili cu facțiunile ilegale.
