# Regulament Staff & Asistență

<h2 align="center"><mark style="color:blue;"><strong>GHIDUL DE CONDUITĂ ȘI ASISTENȚĂ STAFF NEWLIFE</strong></mark></h2>

***

Echipa administrativă a serverului **NewLife** este dedicată asigurării unui mediu de joc curat, corect și plăcut pentru întreaga comunitate. Membrii staff sunt voluntari care își dedică timpul liber ajutării jucătorilor și rezolvării problemelor tehnice sau de comportament.

---

### 🛡️ Îndatoririle Membrilor Staff

1. **Imparțialitate Totală**: Niciun membru staff nu are voie să favorizeze prieteni, membri de facțiune sau cunoștințe în cadrul unui ticket administrativ. Orice decizie trebuie fundamentată exclusiv pe regulament și pe dovezi obiective.
2. **Ton Calm și Respectuos**: Indiferent de comportamentul jucătorilor reclamanți sau acuzați, staff-ul este obligat să mențină un limbaj civilizat, profesional și fără manifestări de superioritate.
3. **Prezență și Activitate**: Moderatorilor și administratorilor li se cere o prezență constantă pe server și pe Discord, preluând cu prioritate rapoartele din joc (`/report`).
4. **Interzis Abuzul de Comenzi (Admin Abuse)**: Folosirea comenzilor administrative (`/teleport`, `/noclip`, `/god`, `/revive`, `/giveitem`) în beneficiu propriu, în roleplay sau pentru a avantaja alte persoane atrage **excluderea imediată din staff și Blacklist**.

---

### 🎫 Preluarea și Soluționarea Ticketelor

{% hint style="info" %}
* **Ascultarea ambelor părți**: Înainte de a da o sancțiune, membrul staff este obligat să asculte versiunea ambilor jucători implicați și să solicite dovezi video complete.
* **Fără decizii în pripă**: Dacă dovezile prezentate sunt neclare sau fragmentate, se acordă beneficiul îndoielii sau se solicită înregistrarea completă a scenei (minim 2 minute înainte de conflict).
* **Returnare Bunuri (Refund)**: În cazul în care un jucător a pierdut bunuri sau mașini din cauza unui bug de server confirmat sau a unui act clar de Cheating/RDM masiv, doar Adminii cu gradul de la **Senior Admin** în sus pot efectua comenzi de refund, pe baza dovezilor clare din log-uri.
{% endhint %}

---

### 🎥 Standarde pentru Dovezi Video

Pentru ca o reclamație împotriva unui jucător sau a unui membru staff să fie validă:
* Filmarea trebuie încărcată pe o platformă publică / necomprimată (YouTube, Medal.tv, Streamable).
* Rezoluția minimă acceptată este de **720p / 30 FPS**.
* Înregistrarea audio trebuie să fie activă (să se audă atât vocea reclamatului, cât și vocea reclamantului).
* Nu se acceptă filmări tăiate sau editate în mod suspect pentru a ascunde provocări sau greșeli proprii.
